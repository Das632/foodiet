import React, { useState } from "react";
import "./App.css";

const sabjis = [
  { name: "Aloo", zone: "red", substitute: "Bhindi, Beans", reason: "High carb" },
  { name: "Bhindi", zone: "green", benefit: "High fiber and low calorie" },
  { name: "Mushroom", zone: "green", benefit: "Rich in plant protein" },
  { name: "Baingan", zone: "red", substitute: "Beans or Bhindi", reason: "Low in nutrients" },
];

function App() {
  const [zone, setZone] = useState("all");

  const filtered = zone === "all" ? sabjis : sabjis.filter(s => s.zone === zone);

  return (
    <div className="App">
      <h1>Sabji Decision Tool</h1>
      <div>
        <button onClick={() => setZone("all")}>All</button>
        <button onClick={() => setZone("green")}>Green Zone ✅</button>
        <button onClick={() => setZone("red")}>Red Zone ❌</button>
      </div>
      <ul>
        {filtered.map((sabji, i) => (
          <li key={i}>
            <strong>{sabji.name}</strong> - {sabji.zone.toUpperCase()}<br />
            {sabji.zone === "red" ? (
              <span>🚫 Avoid. Try: {sabji.substitute} — {sabji.reason}</span>
            ) : (
              <span>✅ Benefit: {sabji.benefit}</span>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;